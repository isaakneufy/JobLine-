import React from 'react'
import { Link } from 'react-router-dom'
import { Hammer, User, LogOut } from 'lucide-react'
import { useAuth } from '../../contexts/AuthContext'
import { Button } from '../ui/Button'

export function Header() {
  const { user, signOut } = useAuth()

  return (
    <header className="bg-white border-b border-secondary-200 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <Link to="/" className="flex items-center space-x-2">
            <Hammer className="h-8 w-8 text-primary-600" />
            <span className="text-xl font-bold text-secondary-900">HandyConnect</span>
          </Link>

          <nav className="hidden md:flex items-center space-x-8">
            <Link to="/jobs" className="text-secondary-600 hover:text-secondary-900 transition-colors">
              Browse Jobs
            </Link>
            <Link to="/contractors" className="text-secondary-600 hover:text-secondary-900 transition-colors">
              Find Contractors
            </Link>
            {user?.user_type === 'consumer' && (
              <Link to="/post-job" className="text-secondary-600 hover:text-secondary-900 transition-colors">
                Post Job
              </Link>
            )}
          </nav>

          <div className="flex items-center space-x-4">
            {user ? (
              <div className="flex items-center space-x-4">
                <Link to="/dashboard" className="flex items-center space-x-2 text-secondary-700 hover:text-secondary-900">
                  <User className="h-5 w-5" />
                  <span>{user.full_name}</span>
                </Link>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => signOut()}
                  className="flex items-center space-x-2"
                >
                  <LogOut className="h-4 w-4" />
                  <span>Sign Out</span>
                </Button>
              </div>
            ) : (
              <div className="flex items-center space-x-4">
                <Link to="/login">
                  <Button variant="ghost" size="sm">Sign In</Button>
                </Link>
                <Link to="/register">
                  <Button size="sm">Get Started</Button>
                </Link>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}