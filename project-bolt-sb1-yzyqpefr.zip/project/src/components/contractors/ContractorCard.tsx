import React from 'react'
import { Link } from 'react-router-dom'
import { Star, MapPin, DollarSign, Briefcase, Shield } from 'lucide-react'
import { Card, CardContent } from '../ui/Card'
import { Button } from '../ui/Button'
import { ContractorProfile } from '../../types'
import { formatCurrency } from '../../lib/utils'

interface ContractorCardProps {
  contractor: ContractorProfile & {
    user?: {
      full_name: string
      avatar_url?: string
      location?: string
      phone?: string
    }
  }
  onContact?: (contractor: ContractorProfile) => void
}

export function ContractorCard({ contractor, onContact }: ContractorCardProps) {
  return (
    <Card className="hover:shadow-md transition-shadow">
      <CardContent className="p-6">
        <div className="flex items-start gap-4 mb-4">
          <div className="w-16 h-16 bg-secondary-200 rounded-full flex items-center justify-center flex-shrink-0">
            {contractor.user?.avatar_url ? (
              <img src={contractor.user.avatar_url} alt="" className="w-16 h-16 rounded-full object-cover" />
            ) : (
              <span className="text-xl font-semibold text-secondary-600">
                {contractor.user?.full_name?.charAt(0)}
              </span>
            )}
          </div>
          
          <div className="flex-1">
            <h3 className="text-lg font-semibold text-secondary-900">
              {contractor.business_name || contractor.user?.full_name}
            </h3>
            {contractor.business_name && (
              <p className="text-secondary-600">{contractor.user?.full_name}</p>
            )}
            
            <div className="flex items-center gap-4 mt-2 text-sm text-secondary-600">
              <div className="flex items-center gap-1">
                <Star className="h-4 w-4 text-yellow-500 fill-current" />
                <span className="font-medium">{contractor.average_rating.toFixed(1)}</span>
                <span>({contractor.total_reviews} reviews)</span>
              </div>
              
              {contractor.user?.location && (
                <div className="flex items-center gap-1">
                  <MapPin className="h-4 w-4" />
                  <span>{contractor.user.location}</span>
                </div>
              )}
            </div>
          </div>
        </div>

        <p className="text-secondary-700 mb-4 line-clamp-2">{contractor.description}</p>

        <div className="flex flex-wrap gap-2 mb-4">
          {contractor.specialties.slice(0, 3).map((specialty, index) => (
            <span
              key={index}
              className="px-2 py-1 bg-primary-50 text-primary-700 rounded-full text-xs font-medium"
            >
              {specialty}
            </span>
          ))}
          {contractor.specialties.length > 3 && (
            <span className="px-2 py-1 bg-secondary-100 text-secondary-600 rounded-full text-xs">
              +{contractor.specialties.length - 3} more
            </span>
          )}
        </div>

        <div className="flex items-center justify-between text-sm text-secondary-600 mb-4">
          <div className="flex items-center gap-4">
            {contractor.hourly_rate && (
              <div className="flex items-center gap-1">
                <DollarSign className="h-4 w-4" />
                <span>{formatCurrency(contractor.hourly_rate)}/hr</span>
              </div>
            )}
            
            <div className="flex items-center gap-1">
              <Briefcase className="h-4 w-4" />
              <span>{contractor.years_experience} years exp.</span>
            </div>
            
            {contractor.insurance_verified && (
              <div className="flex items-center gap-1 text-green-600">
                <Shield className="h-4 w-4" />
                <span>Insured</span>
              </div>
            )}
          </div>
        </div>

        <div className="flex gap-2">
          <Link to={`/contractors/${contractor.user_id}`} className="flex-1">
            <Button variant="outline" size="sm" className="w-full">
              View Profile
            </Button>
          </Link>
          {onContact && (
            <Button size="sm" onClick={() => onContact(contractor)} className="flex-1">
              Contact
            </Button>
          )}
        </div>

        {contractor.portfolio_images && contractor.portfolio_images.length > 0 && (
          <div className="mt-4 flex gap-2 overflow-x-auto">
            {contractor.portfolio_images.slice(0, 4).map((image, index) => (
              <img
                key={index}
                src={image}
                alt={`Portfolio ${index + 1}`}
                className="w-16 h-16 object-cover rounded flex-shrink-0"
              />
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  )
}