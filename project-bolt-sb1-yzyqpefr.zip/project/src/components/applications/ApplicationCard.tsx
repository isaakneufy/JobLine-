import React from 'react'
import { Star, MapPin, DollarSign, Clock, User } from 'lucide-react'
import { Card, CardContent } from '../ui/Card'
import { Button } from '../ui/Button'
import { JobApplication } from '../../types'
import { formatCurrency, formatDate } from '../../lib/utils'

interface ApplicationCardProps {
  application: JobApplication & {
    contractor?: {
      full_name: string
      avatar_url?: string
    }
    contractor_profile?: {
      average_rating: number
      total_reviews: number
      years_experience: number
      specialties: string[]
    }
  }
  onAccept?: (application: JobApplication) => void
  onReject?: (application: JobApplication) => void
  showActions?: boolean
}

export function ApplicationCard({ application, onAccept, onReject, showActions = true }: ApplicationCardProps) {
  const getStatusColor = () => {
    switch (application.status) {
      case 'accepted': return 'text-green-600 bg-green-50'
      case 'rejected': return 'text-red-600 bg-red-50'
      case 'withdrawn': return 'text-gray-600 bg-gray-50'
      default: return 'text-blue-600 bg-blue-50'
    }
  }

  return (
    <Card>
      <CardContent className="p-6">
        <div className="flex items-start justify-between mb-4">
          <div className="flex items-start gap-3">
            <div className="w-12 h-12 bg-secondary-200 rounded-full flex items-center justify-center">
              {application.contractor?.avatar_url ? (
                <img 
                  src={application.contractor.avatar_url} 
                  alt="" 
                  className="w-12 h-12 rounded-full object-cover" 
                />
              ) : (
                <User className="h-6 w-6 text-secondary-600" />
              )}
            </div>
            
            <div>
              <h3 className="font-semibold text-secondary-900">
                {application.contractor?.full_name}
              </h3>
              
              {application.contractor_profile && (
                <div className="flex items-center gap-2 text-sm text-secondary-600 mt-1">
                  <div className="flex items-center gap-1">
                    <Star className="h-3 w-3 text-yellow-500 fill-current" />
                    <span>{application.contractor_profile.average_rating.toFixed(1)}</span>
                    <span>({application.contractor_profile.total_reviews})</span>
                  </div>
                  <span>•</span>
                  <span>{application.contractor_profile.years_experience} years exp.</span>
                </div>
              )}
            </div>
          </div>

          <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor()}`}>
            {application.status.charAt(0).toUpperCase() + application.status.slice(1)}
          </span>
        </div>

        <p className="text-secondary-700 mb-4">{application.message}</p>

        <div className="grid grid-cols-2 md:grid-cols-3 gap-4 text-sm text-secondary-600 mb-4">
          <div className="flex items-center gap-1">
            <DollarSign className="h-4 w-4" />
            <span>{formatCurrency(application.proposed_price)}</span>
          </div>
          <div className="flex items-center gap-1">
            <Clock className="h-4 w-4" />
            <span>{application.estimated_duration}</span>
          </div>
          <div className="col-span-2 md:col-span-1">
            <span className="text-xs text-secondary-500">Available: </span>
            <span>{application.availability}</span>
          </div>
        </div>

        {application.contractor_profile?.specialties && (
          <div className="flex flex-wrap gap-1 mb-4">
            {application.contractor_profile.specialties.slice(0, 3).map((specialty, index) => (
              <span
                key={index}
                className="px-2 py-1 bg-primary-50 text-primary-700 rounded-full text-xs"
              >
                {specialty}
              </span>
            ))}
          </div>
        )}

        <div className="flex items-center justify-between">
          <span className="text-xs text-secondary-500">
            Applied {formatDate(application.created_at)}
          </span>

          {showActions && application.status === 'pending' && onAccept && onReject && (
            <div className="flex gap-2">
              <Button
                size="sm"
                variant="outline"
                onClick={() => onReject(application)}
                className="text-red-600 border-red-300 hover:bg-red-50"
              >
                Reject
              </Button>
              <Button size="sm" onClick={() => onAccept(application)}>
                Accept
              </Button>
            </div>
          )}
        </div>

        {application.consumer_notes && (
          <div className="mt-4 p-3 bg-secondary-50 rounded-lg">
            <p className="text-sm text-secondary-700">
              <span className="font-medium">Note: </span>
              {application.consumer_notes}
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  )
}