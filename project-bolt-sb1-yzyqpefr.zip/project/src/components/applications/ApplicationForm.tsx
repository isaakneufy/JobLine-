import React, { useState } from 'react'
import { useJobApplications } from '../../hooks/useJobApplications'
import { useAuth } from '../../contexts/AuthContext'
import { Button } from '../ui/Button'
import { Input } from '../ui/Input'
import { Card, CardContent, CardHeader } from '../ui/Card'
import { Job } from '../../types'

interface ApplicationFormProps {
  job: Job
  onSuccess: () => void
  onCancel: () => void
}

export function ApplicationForm({ job, onSuccess, onCancel }: ApplicationFormProps) {
  const { user } = useAuth()
  const { createApplication } = useJobApplications()
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  
  const [formData, setFormData] = useState({
    message: '',
    proposed_price: '',
    estimated_duration: '',
    availability: ''
  })

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!user) return

    setLoading(true)
    setError('')

    try {
      await createApplication({
        job_id: job.id,
        contractor_id: user.id,
        message: formData.message,
        proposed_price: parseFloat(formData.proposed_price),
        estimated_duration: formData.estimated_duration,
        availability: formData.availability
      })

      onSuccess()
    } catch (err: any) {
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }

  return (
    <Card className="max-w-2xl mx-auto">
      <CardHeader>
        <h2 className="text-xl font-bold text-secondary-900">Apply for Job</h2>
        <p className="text-secondary-600">{job.title}</p>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <label className="block text-sm font-medium text-secondary-700">
              Cover Message
            </label>
            <textarea
              value={formData.message}
              onChange={(e) => setFormData({ ...formData, message: e.target.value })}
              rows={4}
              className="block w-full rounded-lg border border-secondary-300 px-3 py-2 text-sm focus:border-primary-500 focus:outline-none focus:ring-1 focus:ring-primary-500"
              placeholder="Explain why you're the right person for this job..."
              required
            />
          </div>

          <Input
            label="Proposed Price ($)"
            type="number"
            step="0.01"
            value={formData.proposed_price}
            onChange={(e) => setFormData({ ...formData, proposed_price: e.target.value })}
            placeholder="Enter your price for this job"
            required
          />

          <Input
            label="Estimated Duration"
            value={formData.estimated_duration}
            onChange={(e) => setFormData({ ...formData, estimated_duration: e.target.value })}
            placeholder="e.g., 2-3 hours, 1 day, 1 week"
            required
          />

          <Input
            label="Your Availability"
            value={formData.availability}
            onChange={(e) => setFormData({ ...formData, availability: e.target.value })}
            placeholder="e.g., Available this weekend, Can start Monday"
            required
          />

          {error && (
            <div className="text-red-600 text-sm">{error}</div>
          )}

          <div className="flex gap-4">
            <Button type="submit" disabled={loading} className="flex-1">
              {loading ? 'Submitting...' : 'Submit Application'}
            </Button>
            <Button type="button" variant="outline" onClick={onCancel}>
              Cancel
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  )
}