import React from 'react'
import { Link } from 'react-router-dom'
import { MapPin, Clock, DollarSign, User } from 'lucide-react'
import { Card, CardContent } from '../ui/Card'
import { Button } from '../ui/Button'
import { Job } from '../../types'
import { formatCurrency, formatDate } from '../../lib/utils'

interface JobCardProps {
  job: Job & {
    consumer?: {
      full_name: string
      avatar_url?: string
      location?: string
    }
  }
  showApplyButton?: boolean
  onApply?: (job: Job) => void
}

export function JobCard({ job, showApplyButton = false, onApply }: JobCardProps) {
  const getBudgetDisplay = () => {
    if (job.budget_min && job.budget_max) {
      return `${formatCurrency(job.budget_min)} - ${formatCurrency(job.budget_max)}`
    } else if (job.budget_min) {
      return `From ${formatCurrency(job.budget_min)}`
    } else if (job.budget_max) {
      return `Up to ${formatCurrency(job.budget_max)}`
    }
    return 'Budget negotiable'
  }

  const getUrgencyColor = () => {
    switch (job.urgency) {
      case 'urgent': return 'text-red-600 bg-red-50'
      case 'high': return 'text-orange-600 bg-orange-50'
      case 'normal': return 'text-blue-600 bg-blue-50'
      case 'low': return 'text-gray-600 bg-gray-50'
      default: return 'text-blue-600 bg-blue-50'
    }
  }

  return (
    <Card className="hover:shadow-md transition-shadow">
      <CardContent className="p-6">
        <div className="flex justify-between items-start mb-4">
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-2">
              <h3 className="text-lg font-semibold text-secondary-900">{job.title}</h3>
              <span className={`px-2 py-1 rounded-full text-xs font-medium ${getUrgencyColor()}`}>
                {job.urgency?.charAt(0).toUpperCase() + job.urgency?.slice(1)}
              </span>
            </div>
            <p className="text-secondary-600 mb-3 line-clamp-2">{job.description}</p>
          </div>
        </div>

        <div className="flex flex-wrap gap-4 text-sm text-secondary-600 mb-4">
          <div className="flex items-center gap-1">
            <DollarSign className="h-4 w-4" />
            <span>{getBudgetDisplay()}</span>
          </div>
          <div className="flex items-center gap-1">
            <Clock className="h-4 w-4" />
            <span>{job.timeline}</span>
          </div>
          <div className="flex items-center gap-1">
            <MapPin className="h-4 w-4" />
            <span>{job.location}</span>
          </div>
        </div>

        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-secondary-200 rounded-full flex items-center justify-center">
              {job.consumer?.avatar_url ? (
                <img src={job.consumer.avatar_url} alt="" className="w-8 h-8 rounded-full" />
              ) : (
                <User className="h-4 w-4 text-secondary-600" />
              )}
            </div>
            <div>
              <p className="text-sm font-medium text-secondary-900">{job.consumer?.full_name}</p>
              <p className="text-xs text-secondary-500">Posted {formatDate(job.created_at)}</p>
            </div>
          </div>

          <div className="flex gap-2">
            <Link to={`/jobs/${job.id}`}>
              <Button variant="outline" size="sm">View Details</Button>
            </Link>
            {showApplyButton && onApply && (
              <Button size="sm" onClick={() => onApply(job)}>
                Apply Now
              </Button>
            )}
          </div>
        </div>

        {job.images && job.images.length > 0 && (
          <div className="mt-4 flex gap-2 overflow-x-auto">
            {job.images.slice(0, 3).map((image, index) => (
              <img
                key={index}
                src={image}
                alt={`Job image ${index + 1}`}
                className="w-16 h-16 object-cover rounded flex-shrink-0"
              />
            ))}
            {job.images.length > 3 && (
              <div className="w-16 h-16 bg-secondary-100 rounded flex items-center justify-center text-xs text-secondary-600">
                +{job.images.length - 3}
              </div>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  )
}