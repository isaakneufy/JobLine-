export interface User {
  id: string
  email: string
  full_name: string
  user_type: 'consumer' | 'contractor'
  avatar_url?: string
  created_at: string
}

export interface ContractorProfile {
  id: string
  user_id: string
  business_name?: string
  description: string
  specialties: string[]
  hourly_rate?: number
  years_experience: number
  license_number?: string
  insurance_verified: boolean
  average_rating: number
  total_jobs: number
  created_at: string
}

export interface Job {
  id: string
  consumer_id: string
  title: string
  description: string
  category: string
  budget_min: number
  budget_max: number
  timeline: string
  location: string
  images: string[]
  status: 'open' | 'in_progress' | 'completed' | 'cancelled'
  created_at: string
  updated_at: string
}

export interface JobApplication {
  id: string
  job_id: string
  contractor_id: string
  message: string
  proposed_price: number
  estimated_duration: string
  status: 'pending' | 'accepted' | 'rejected'
  created_at: string
}

export interface Review {
  id: string
  job_id: string
  reviewer_id: string
  reviewee_id: string
  rating: number
  comment: string
  created_at: string
}