import React, { useState } from 'react'
import { useContractors } from '../hooks/useContractors'
import { ContractorCard } from '../components/contractors/ContractorCard'
import { Button } from '../components/ui/Button'
import { Input } from '../components/ui/Input'
import { Card, CardContent } from '../components/ui/Card'
import { Search, Star } from 'lucide-react'
import { ContractorProfile } from '../types'

const SPECIALTIES = [
  'All', 'Plumbing', 'Electrical', 'Carpentry', 'Painting', 'Landscaping',
  'Cleaning', 'Handyman', 'Moving', 'HVAC', 'Roofing', 'Flooring', 'Appliance Repair'
]

export function ContractorsPage() {
  const { contractors, loading, fetchContractors } = useContractors()
  const [filters, setFilters] = useState({
    specialty: 'All',
    location: '',
    minRating: '',
    maxRate: ''
  })

  const handleSearch = () => {
    const searchFilters: any = {}
    if (filters.specialty !== 'All') searchFilters.specialty = filters.specialty
    if (filters.location) searchFilters.location = filters.location
    if (filters.minRating) searchFilters.minRating = parseFloat(filters.minRating)
    if (filters.maxRate) searchFilters.maxRate = parseFloat(filters.maxRate)
    
    fetchContractors(searchFilters)
  }

  const handleContact = (contractor: ContractorProfile) => {
    // In a real app, this would open a messaging interface
    console.log('Contact contractor:', contractor)
  }

  return (
    <div className="min-h-screen bg-secondary-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-secondary-900 mb-2">Find Contractors</h1>
          <p className="text-secondary-600">Browse qualified professionals in your area</p>
        </div>

        {/* Filters */}
        <Card className="mb-8">
          <CardContent className="p-6">
            <div className="grid md:grid-cols-4 gap-4">
              <div className="space-y-2">
                <label className="block text-sm font-medium text-secondary-700">Specialty</label>
                <select
                  value={filters.specialty}
                  onChange={(e) => setFilters({ ...filters, specialty: e.target.value })}
                  className="block w-full rounded-lg border border-secondary-300 px-3 py-2 text-sm focus:border-primary-500 focus:outline-none focus:ring-1 focus:ring-primary-500"
                >
                  {SPECIALTIES.map(specialty => (
                    <option key={specialty} value={specialty}>{specialty}</option>
                  ))}
                </select>
              </div>

              <Input
                label="Location"
                value={filters.location}
                onChange={(e) => setFilters({ ...filters, location: e.target.value })}
                placeholder="City, State"
              />

              <div className="space-y-2">
                <label className="block text-sm font-medium text-secondary-700">Min Rating</label>
                <select
                  value={filters.minRating}
                  onChange={(e) => setFilters({ ...filters, minRating: e.target.value })}
                  className="block w-full rounded-lg border border-secondary-300 px-3 py-2 text-sm focus:border-primary-500 focus:outline-none focus:ring-1 focus:ring-primary-500"
                >
                  <option value="">Any Rating</option>
                  <option value="4">4+ Stars</option>
                  <option value="4.5">4.5+ Stars</option>
                  <option value="4.8">4.8+ Stars</option>
                </select>
              </div>

              <Input
                label="Max Rate ($/hr)"
                type="number"
                value={filters.maxRate}
                onChange={(e) => setFilters({ ...filters, maxRate: e.target.value })}
                placeholder="100"
              />
            </div>

            <div className="mt-4 flex gap-2">
              <Button onClick={handleSearch} className="flex items-center gap-2">
                <Search className="h-4 w-4" />
                Search Contractors
              </Button>
              <Button
                variant="outline"
                onClick={() => {
                  setFilters({ specialty: 'All', location: '', minRating: '', maxRate: '' })
                  fetchContractors()
                }}
              >
                Clear Filters
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Contractors Grid */}
        {loading ? (
          <div className="text-center py-8">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-600 mx-auto mb-4"></div>
            <p className="text-secondary-600">Loading contractors...</p>
          </div>
        ) : contractors.length === 0 ? (
          <Card>
            <CardContent className="p-8 text-center">
              <p className="text-secondary-600">No contractors found matching your criteria.</p>
            </CardContent>
          </Card>
        ) : (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {contractors.map(contractor => (
              <ContractorCard
                key={contractor.id}
                contractor={contractor}
                onContact={handleContact}
              />
            ))}
          </div>
        )}
      </div>
    </div>
  )
}