import React, { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import { useAuth } from '../contexts/AuthContext'
import { useJobs } from '../hooks/useJobs'
import { useJobApplications } from '../hooks/useJobApplications'
import { Card, CardContent, CardHeader } from '../components/ui/Card'
import { Button } from '../components/ui/Button'
import { JobCard } from '../components/jobs/JobCard'
import { ApplicationCard } from '../components/applications/ApplicationCard'
import { Plus, Briefcase, Star, DollarSign, Clock } from 'lucide-react'
import { supabase } from '../lib/supabase'

export function DashboardPage() {
  const { user } = useAuth()
  const { jobs, fetchJobs } = useJobs()
  const { applications, fetchApplications, updateApplicationStatus } = useJobApplications()
  const [stats, setStats] = useState({
    activeJobs: 0,
    completedJobs: 0,
    totalSpent: 0,
    totalEarned: 0
  })

  useEffect(() => {
    if (user) {
      if (user.user_type === 'consumer') {
        fetchJobs()
        fetchConsumerStats()
      } else {
        fetchApplications()
        fetchContractorStats()
      }
    }
  }, [user])

  const fetchConsumerStats = async () => {
    if (!user) return
    
    try {
      const { data: jobStats } = await supabase
        .from('jobs')
        .select('status')
        .eq('consumer_id', user.id)

      const activeJobs = jobStats?.filter(j => j.status === 'open' || j.status === 'in_progress').length || 0
      const completedJobs = jobStats?.filter(j => j.status === 'completed').length || 0

      setStats(prev => ({ ...prev, activeJobs, completedJobs }))
    } catch (error) {
      console.error('Error fetching consumer stats:', error)
    }
  }

  const fetchContractorStats = async () => {
    if (!user) return
    
    try {
      const { data: appStats } = await supabase
        .from('job_applications')
        .select('status')
        .eq('contractor_id', user.id)

      const activeJobs = appStats?.filter(a => a.status === 'accepted').length || 0

      setStats(prev => ({ ...prev, activeJobs }))
    } catch (error) {
      console.error('Error fetching contractor stats:', error)
    }
  }

  const handleAcceptApplication = async (application: any) => {
    try {
      await updateApplicationStatus(application.id, 'accepted')
      fetchApplications()
    } catch (error) {
      console.error('Error accepting application:', error)
    }
  }

  const handleRejectApplication = async (application: any) => {
    try {
      await updateApplicationStatus(application.id, 'rejected')
      fetchApplications()
    } catch (error) {
      console.error('Error rejecting application:', error)
    }
  }

  if (!user) return null

  return (
    <div className="min-h-screen bg-secondary-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-secondary-900">
            Welcome back, {user.full_name}!
          </h1>
          <p className="text-secondary-600 mt-2">
            {user.user_type === 'consumer' 
              ? 'Manage your projects and find contractors'
              : 'Find new jobs and manage your business'
            }
          </p>
        </div>

        {user.user_type === 'consumer' ? (
          <ConsumerDashboard 
            jobs={jobs} 
            stats={stats}
            applications={applications}
            onAcceptApplication={handleAcceptApplication}
            onRejectApplication={handleRejectApplication}
          />
        ) : (
          <ContractorDashboard 
            applications={applications}
            stats={stats}
          />
        )}
      </div>
    </div>
  )
}

function ConsumerDashboard({ jobs, stats, applications, onAcceptApplication, onRejectApplication }: any) {
  const myJobs = jobs.filter((job: any) => job.status !== 'completed')
  const jobApplications = applications.filter((app: any) => app.status === 'pending')

  return (
    <div className="space-y-8">
      {/* Quick Actions */}
      <Card>
        <CardHeader>
          <h2 className="text-xl font-semibold text-secondary-900">Quick Actions</h2>
        </CardHeader>
        <CardContent>
          <div className="flex flex-wrap gap-4">
            <Link to="/post-job">
              <Button className="flex items-center space-x-2">
                <Plus className="h-4 w-4" />
                <span>Post New Job</span>
              </Button>
            </Link>
            <Link to="/contractors">
              <Button variant="outline" className="flex items-center space-x-2">
                <Briefcase className="h-4 w-4" />
                <span>Browse Contractors</span>
              </Button>
            </Link>
          </div>
        </CardContent>
      </Card>

      {/* Stats */}
      <div className="grid md:grid-cols-3 gap-6">
        <Card>
          <CardContent className="p-6 text-center">
            <Briefcase className="h-8 w-8 text-primary-600 mx-auto mb-2" />
            <div className="text-2xl font-bold text-secondary-900">{stats.activeJobs}</div>
            <div className="text-secondary-600">Active Jobs</div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6 text-center">
            <Star className="h-8 w-8 text-primary-600 mx-auto mb-2" />
            <div className="text-2xl font-bold text-secondary-900">{stats.completedJobs}</div>
            <div className="text-secondary-600">Completed Jobs</div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6 text-center">
            <DollarSign className="h-8 w-8 text-primary-600 mx-auto mb-2" />
            <div className="text-2xl font-bold text-secondary-900">${stats.totalSpent}</div>
            <div className="text-secondary-600">Total Spent</div>
          </CardContent>
        </Card>
      </div>

      {/* Pending Applications */}
      {jobApplications.length > 0 && (
        <Card>
          <CardHeader>
            <h2 className="text-xl font-semibold text-secondary-900">Pending Applications</h2>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {jobApplications.slice(0, 3).map((application: any) => (
                <ApplicationCard
                  key={application.id}
                  application={application}
                  onAccept={onAcceptApplication}
                  onReject={onRejectApplication}
                />
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Recent Jobs */}
      <Card>
        <CardHeader>
          <h2 className="text-xl font-semibold text-secondary-900">Your Jobs</h2>
        </CardHeader>
        <CardContent>
          {myJobs.length === 0 ? (
            <div className="text-center py-8 text-secondary-500">
              <Briefcase className="h-12 w-12 mx-auto mb-4 opacity-50" />
              <p>No jobs posted yet</p>
              <Link to="/post-job">
                <Button className="mt-4">Post Your First Job</Button>
              </Link>
            </div>
          ) : (
            <div className="space-y-4">
              {myJobs.slice(0, 3).map((job: any) => (
                <JobCard key={job.id} job={job} />
              ))}
              {myJobs.length > 3 && (
                <div className="text-center">
                  <Button variant="outline">View All Jobs</Button>
                </div>
              )}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}

function ContractorDashboard({ applications, stats }: any) {
  const myApplications = applications.slice(0, 5)

  return (
    <div className="space-y-8">
      {/* Quick Actions */}
      <Card>
        <CardHeader>
          <h2 className="text-xl font-semibold text-secondary-900">Quick Actions</h2>
        </CardHeader>
        <CardContent>
          <div className="flex flex-wrap gap-4">
            <Link to="/jobs">
              <Button className="flex items-center space-x-2">
                <Briefcase className="h-4 w-4" />
                <span>Browse Jobs</span>
              </Button>
            </Link>
            <Link to="/profile">
              <Button variant="outline" className="flex items-center space-x-2">
                <Star className="h-4 w-4" />
                <span>Update Profile</span>
              </Button>
            </Link>
          </div>
        </CardContent>
      </Card>

      {/* Stats */}
      <div className="grid md:grid-cols-3 gap-6">
        <Card>
          <CardContent className="p-6 text-center">
            <Briefcase className="h-8 w-8 text-primary-600 mx-auto mb-2" />
            <div className="text-2xl font-bold text-secondary-900">{stats.activeJobs}</div>
            <div className="text-secondary-600">Active Jobs</div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6 text-center">
            <Clock className="h-8 w-8 text-primary-600 mx-auto mb-2" />
            <div className="text-2xl font-bold text-secondary-900">{applications.length}</div>
            <div className="text-secondary-600">Applications</div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6 text-center">
            <DollarSign className="h-8 w-8 text-primary-600 mx-auto mb-2" />
            <div className="text-2xl font-bold text-secondary-900">${stats.totalEarned}</div>
            <div className="text-secondary-600">Total Earned</div>
          </CardContent>
        </Card>
      </div>

      {/* My Applications */}
      <Card>
        <CardHeader>
          <h2 className="text-xl font-semibold text-secondary-900">My Applications</h2>
        </CardHeader>
        <CardContent>
          {myApplications.length === 0 ? (
            <div className="text-center py-8 text-secondary-500">
              <Briefcase className="h-12 w-12 mx-auto mb-4 opacity-50" />
              <p>No applications yet</p>
              <Link to="/jobs">
                <Button className="mt-4">Browse Available Jobs</Button>
              </Link>
            </div>
          ) : (
            <div className="space-y-4">
              {myApplications.map((application: any) => (
                <ApplicationCard 
                  key={application.id} 
                  application={application} 
                  showActions={false}
                />
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}