import React from 'react'
import { Link } from 'react-router-dom'
import { Search, Shield, Star, Clock } from 'lucide-react'
import { Button } from '../components/ui/Button'
import { Card, CardContent } from '../components/ui/Card'

export function HomePage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-primary-50 to-secondary-50">
      {/* Hero Section */}
      <section className="relative py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto text-center">
          <h1 className="text-4xl md:text-6xl font-bold text-secondary-900 mb-6">
            Connect with Trusted
            <span className="text-primary-600 block">Local Contractors</span>
          </h1>
          <p className="text-xl text-secondary-600 mb-8 max-w-3xl mx-auto">
            From small repairs to major renovations, find skilled professionals for any job. 
            Post your project and get matched with qualified contractors in your area.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to="/register">
              <Button size="lg" className="w-full sm:w-auto">
                Post a Job
              </Button>
            </Link>
            <Link to="/contractors">
              <Button variant="outline" size="lg" className="w-full sm:w-auto">
                Find Contractors
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 bg-white">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-3xl font-bold text-center text-secondary-900 mb-12">
            How HandyConnect Works
          </h2>
          <div className="grid md:grid-cols-3 gap-8">
            <Card className="text-center p-6">
              <CardContent>
                <Search className="h-12 w-12 text-primary-600 mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-secondary-900 mb-2">
                  Post Your Project
                </h3>
                <p className="text-secondary-600">
                  Describe your project with photos, timeline, and budget. 
                  Get matched with qualified contractors.
                </p>
              </CardContent>
            </Card>
            
            <Card className="text-center p-6">
              <CardContent>
                <Shield className="h-12 w-12 text-primary-600 mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-secondary-900 mb-2">
                  Choose Your Pro
                </h3>
                <p className="text-secondary-600">
                  Review profiles, ratings, and proposals. 
                  Select the contractor that's right for you.
                </p>
              </CardContent>
            </Card>
            
            <Card className="text-center p-6">
              <CardContent>
                <Star className="h-12 w-12 text-primary-600 mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-secondary-900 mb-2">
                  Get It Done
                </h3>
                <p className="text-secondary-600">
                  Work with your chosen contractor to complete the project. 
                  Rate and review when finished.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 bg-primary-600">
        <div className="max-w-7xl mx-auto">
          <div className="grid md:grid-cols-3 gap-8 text-center text-white">
            <div>
              <div className="text-4xl font-bold mb-2">10,000+</div>
              <div className="text-primary-100">Projects Completed</div>
            </div>
            <div>
              <div className="text-4xl font-bold mb-2">5,000+</div>
              <div className="text-primary-100">Verified Contractors</div>
            </div>
            <div>
              <div className="text-4xl font-bold mb-2">4.8/5</div>
              <div className="text-primary-100">Average Rating</div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 bg-secondary-50">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl font-bold text-secondary-900 mb-4">
            Ready to Get Started?
          </h2>
          <p className="text-xl text-secondary-600 mb-8">
            Join thousands of homeowners and contractors who trust HandyConnect
          </p>
          <Link to="/register">
            <Button size="lg">
              Create Your Account Today
            </Button>
          </Link>
        </div>
      </section>
    </div>
  )
}