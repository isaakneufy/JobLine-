import React, { useState } from 'react'
import { useJobs } from '../hooks/useJobs'
import { useAuth } from '../contexts/AuthContext'
import { JobCard } from '../components/jobs/JobCard'
import { ApplicationForm } from '../components/applications/ApplicationForm'
import { Button } from '../components/ui/Button'
import { Input } from '../components/ui/Input'
import { Card, CardContent } from '../components/ui/Card'
import { Search, Filter } from 'lucide-react'
import { Job } from '../types'

const JOB_CATEGORIES = [
  'All', 'Plumbing', 'Electrical', 'Carpentry', 'Painting', 'Landscaping',
  'Cleaning', 'Handyman', 'Moving', 'HVAC', 'Roofing', 'Flooring', 'Appliance Repair'
]

export function JobsPage() {
  const { user } = useAuth()
  const { jobs, loading, fetchJobs } = useJobs()
  const [selectedJob, setSelectedJob] = useState<Job | null>(null)
  const [showApplicationForm, setShowApplicationForm] = useState(false)
  const [filters, setFilters] = useState({
    category: 'All',
    location: '',
    budgetMin: '',
    budgetMax: ''
  })

  const handleApply = (job: Job) => {
    setSelectedJob(job)
    setShowApplicationForm(true)
  }

  const handleApplicationSuccess = () => {
    setShowApplicationForm(false)
    setSelectedJob(null)
    // Show success message
  }

  const handleSearch = () => {
    const searchFilters: any = {}
    if (filters.category !== 'All') searchFilters.category = filters.category
    if (filters.location) searchFilters.location = filters.location
    if (filters.budgetMin) searchFilters.budgetMin = parseFloat(filters.budgetMin)
    if (filters.budgetMax) searchFilters.budgetMax = parseFloat(filters.budgetMax)
    
    fetchJobs({ ...searchFilters, status: 'open' })
  }

  if (showApplicationForm && selectedJob) {
    return (
      <div className="min-h-screen bg-secondary-50 py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <ApplicationForm
            job={selectedJob}
            onSuccess={handleApplicationSuccess}
            onCancel={() => setShowApplicationForm(false)}
          />
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-secondary-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-secondary-900 mb-2">Available Jobs</h1>
          <p className="text-secondary-600">Find jobs that match your skills and schedule</p>
        </div>

        {/* Filters */}
        <Card className="mb-8">
          <CardContent className="p-6">
            <div className="grid md:grid-cols-4 gap-4">
              <div className="space-y-2">
                <label className="block text-sm font-medium text-secondary-700">Category</label>
                <select
                  value={filters.category}
                  onChange={(e) => setFilters({ ...filters, category: e.target.value })}
                  className="block w-full rounded-lg border border-secondary-300 px-3 py-2 text-sm focus:border-primary-500 focus:outline-none focus:ring-1 focus:ring-primary-500"
                >
                  {JOB_CATEGORIES.map(category => (
                    <option key={category} value={category}>{category}</option>
                  ))}
                </select>
              </div>

              <Input
                label="Location"
                value={filters.location}
                onChange={(e) => setFilters({ ...filters, location: e.target.value })}
                placeholder="City, State"
              />

              <Input
                label="Min Budget ($)"
                type="number"
                value={filters.budgetMin}
                onChange={(e) => setFilters({ ...filters, budgetMin: e.target.value })}
                placeholder="0"
              />

              <Input
                label="Max Budget ($)"
                type="number"
                value={filters.budgetMax}
                onChange={(e) => setFilters({ ...filters, budgetMax: e.target.value })}
                placeholder="1000"
              />
            </div>

            <div className="mt-4 flex gap-2">
              <Button onClick={handleSearch} className="flex items-center gap-2">
                <Search className="h-4 w-4" />
                Search Jobs
              </Button>
              <Button
                variant="outline"
                onClick={() => {
                  setFilters({ category: 'All', location: '', budgetMin: '', budgetMax: '' })
                  fetchJobs({ status: 'open' })
                }}
              >
                Clear Filters
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Jobs List */}
        {loading ? (
          <div className="text-center py-8">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-600 mx-auto mb-4"></div>
            <p className="text-secondary-600">Loading jobs...</p>
          </div>
        ) : jobs.length === 0 ? (
          <Card>
            <CardContent className="p-8 text-center">
              <p className="text-secondary-600">No jobs found matching your criteria.</p>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-6">
            {jobs.map(job => (
              <JobCard
                key={job.id}
                job={job}
                showApplyButton={user?.user_type === 'contractor'}
                onApply={handleApply}
              />
            ))}
          </div>
        )}
      </div>
    </div>
  )
}