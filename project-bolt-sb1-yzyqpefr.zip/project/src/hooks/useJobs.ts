import { useState, useEffect } from 'react'
import { supabase } from '../lib/supabase'
import { Job } from '../types'

export function useJobs() {
  const [jobs, setJobs] = useState<Job[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  const fetchJobs = async (filters?: {
    category?: string
    location?: string
    budgetMin?: number
    budgetMax?: number
    status?: string
  }) => {
    try {
      setLoading(true)
      let query = supabase
        .from('jobs')
        .select(`
          *,
          consumer:users!jobs_consumer_id_fkey(full_name, avatar_url, location)
        `)
        .order('created_at', { ascending: false })

      if (filters?.category) {
        query = query.eq('category', filters.category)
      }
      if (filters?.location) {
        query = query.ilike('location', `%${filters.location}%`)
      }
      if (filters?.budgetMin) {
        query = query.gte('budget_min', filters.budgetMin)
      }
      if (filters?.budgetMax) {
        query = query.lte('budget_max', filters.budgetMax)
      }
      if (filters?.status) {
        query = query.eq('status', filters.status)
      }

      const { data, error } = await query

      if (error) throw error
      setJobs(data || [])
    } catch (err: any) {
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }

  const createJob = async (jobData: Omit<Job, 'id' | 'created_at' | 'updated_at'>) => {
    try {
      const { data, error } = await supabase
        .from('jobs')
        .insert(jobData)
        .select()
        .single()

      if (error) throw error
      return data
    } catch (err: any) {
      throw new Error(err.message)
    }
  }

  const updateJob = async (id: string, updates: Partial<Job>) => {
    try {
      const { data, error } = await supabase
        .from('jobs')
        .update(updates)
        .eq('id', id)
        .select()
        .single()

      if (error) throw error
      return data
    } catch (err: any) {
      throw new Error(err.message)
    }
  }

  useEffect(() => {
    fetchJobs()
  }, [])

  return {
    jobs,
    loading,
    error,
    fetchJobs,
    createJob,
    updateJob,
    refetch: fetchJobs
  }
}