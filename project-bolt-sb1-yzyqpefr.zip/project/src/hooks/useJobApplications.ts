import { useState, useEffect } from 'react'
import { supabase } from '../lib/supabase'
import { JobApplication } from '../types'

export function useJobApplications(jobId?: string) {
  const [applications, setApplications] = useState<JobApplication[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  const fetchApplications = async () => {
    try {
      setLoading(true)
      let query = supabase
        .from('job_applications')
        .select(`
          *,
          contractor:users!job_applications_contractor_id_fkey(full_name, avatar_url),
          contractor_profile:contractor_profiles!job_applications_contractor_id_fkey(*)
        `)
        .order('created_at', { ascending: false })

      if (jobId) {
        query = query.eq('job_id', jobId)
      }

      const { data, error } = await query

      if (error) throw error
      setApplications(data || [])
    } catch (err: any) {
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }

  const createApplication = async (applicationData: Omit<JobApplication, 'id' | 'created_at' | 'updated_at' | 'status'>) => {
    try {
      const { data, error } = await supabase
        .from('job_applications')
        .insert(applicationData)
        .select()
        .single()

      if (error) throw error
      return data
    } catch (err: any) {
      throw new Error(err.message)
    }
  }

  const updateApplicationStatus = async (id: string, status: 'accepted' | 'rejected', consumerNotes?: string) => {
    try {
      const { data, error } = await supabase
        .from('job_applications')
        .update({ status, consumer_notes: consumerNotes })
        .eq('id', id)
        .select()
        .single()

      if (error) throw error
      return data
    } catch (err: any) {
      throw new Error(err.message)
    }
  }

  useEffect(() => {
    if (jobId) {
      fetchApplications()
    }
  }, [jobId])

  return {
    applications,
    loading,
    error,
    fetchApplications,
    createApplication,
    updateApplicationStatus,
    refetch: fetchApplications
  }
}