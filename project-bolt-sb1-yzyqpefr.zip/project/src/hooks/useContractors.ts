import { useState, useEffect } from 'react'
import { supabase } from '../lib/supabase'
import { ContractorProfile } from '../types'

export function useContractors() {
  const [contractors, setContractors] = useState<ContractorProfile[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  const fetchContractors = async (filters?: {
    specialty?: string
    location?: string
    minRating?: number
    maxRate?: number
  }) => {
    try {
      setLoading(true)
      let query = supabase
        .from('contractor_profiles')
        .select(`
          *,
          user:users!contractor_profiles_user_id_fkey(full_name, avatar_url, location, phone)
        `)
        .order('average_rating', { ascending: false })

      if (filters?.specialty) {
        query = query.contains('specialties', [filters.specialty])
      }
      if (filters?.minRating) {
        query = query.gte('average_rating', filters.minRating)
      }
      if (filters?.maxRate) {
        query = query.lte('hourly_rate', filters.maxRate)
      }

      const { data, error } = await query

      if (error) throw error
      setContractors(data || [])
    } catch (err: any) {
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }

  const updateProfile = async (updates: Partial<ContractorProfile>) => {
    try {
      const { data, error } = await supabase
        .from('contractor_profiles')
        .update(updates)
        .eq('user_id', (await supabase.auth.getUser()).data.user?.id)
        .select()
        .single()

      if (error) throw error
      return data
    } catch (err: any) {
      throw new Error(err.message)
    }
  }

  useEffect(() => {
    fetchContractors()
  }, [])

  return {
    contractors,
    loading,
    error,
    fetchContractors,
    updateProfile,
    refetch: fetchContractors
  }
}