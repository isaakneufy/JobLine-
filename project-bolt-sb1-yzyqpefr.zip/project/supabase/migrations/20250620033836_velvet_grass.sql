/*
  # Create messages table for communication

  1. New Tables
    - `messages`
      - `id` (uuid, primary key)
      - `job_id` (uuid, foreign key) - references jobs table
      - `sender_id` (uuid, foreign key) - who sent the message
      - `recipient_id` (uuid, foreign key) - who receives the message
      - `content` (text) - message content
      - `message_type` (text) - type of message
      - `read_at` (timestamp, optional) - when message was read
      - `created_at` (timestamp)

  2. Security
    - Enable RLS on `messages` table
    - Add policy for job participants to send/receive messages
*/

CREATE TABLE IF NOT EXISTS messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  job_id uuid NOT NULL REFERENCES jobs(id) ON DELETE CASCADE,
  sender_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  recipient_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  content text NOT NULL,
  message_type text DEFAULT 'text' CHECK (message_type IN ('text', 'system', 'image')),
  read_at timestamptz,
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE messages ENABLE ROW LEVEL SECURITY;

-- Job participants can send and receive messages
CREATE POLICY "Job participants can manage messages"
  ON messages
  FOR ALL
  TO authenticated
  USING (
    (sender_id = auth.uid() OR recipient_id = auth.uid()) AND
    (
      -- Consumer and contractor involved in the job
      EXISTS (
        SELECT 1 FROM jobs j
        LEFT JOIN job_applications ja ON j.id = ja.job_id
        WHERE j.id = job_id 
        AND (
          (j.consumer_id = auth.uid()) OR
          (ja.contractor_id = auth.uid() AND ja.status = 'accepted')
        )
      )
    )
  );

-- Index for better performance
CREATE INDEX IF NOT EXISTS idx_messages_job_id ON messages(job_id);
CREATE INDEX IF NOT EXISTS idx_messages_participants ON messages(sender_id, recipient_id);
CREATE INDEX IF NOT EXISTS idx_messages_created_at ON messages(created_at DESC);