/*
  # Create contractor profiles table

  1. New Tables
    - `contractor_profiles`
      - `id` (uuid, primary key)
      - `user_id` (uuid, foreign key) - references users table
      - `business_name` (text, optional) - contractor's business name
      - `description` (text) - detailed description of services
      - `specialties` (text array) - list of specialties/skills
      - `hourly_rate` (decimal, optional) - hourly rate in dollars
      - `years_experience` (integer) - years of experience
      - `license_number` (text, optional) - professional license number
      - `insurance_verified` (boolean) - whether insurance is verified
      - `portfolio_images` (text array) - URLs to portfolio images
      - `service_radius` (integer) - service radius in miles
      - `availability` (jsonb) - availability schedule
      - `average_rating` (decimal) - calculated average rating
      - `total_jobs` (integer) - total completed jobs
      - `total_reviews` (integer) - total number of reviews
      - `created_at` (timestamp)
      - `updated_at` (timestamp)

  2. Security
    - Enable RLS on `contractor_profiles` table
    - Add policy for contractors to manage their own profiles
    - Add policy for public read access to contractor profiles
*/

CREATE TABLE IF NOT EXISTS contractor_profiles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid UNIQUE NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  business_name text,
  description text NOT NULL DEFAULT '',
  specialties text[] DEFAULT '{}',
  hourly_rate decimal(10,2),
  years_experience integer DEFAULT 0,
  license_number text,
  insurance_verified boolean DEFAULT false,
  portfolio_images text[] DEFAULT '{}',
  service_radius integer DEFAULT 25,
  availability jsonb DEFAULT '{}',
  average_rating decimal(3,2) DEFAULT 0.00,
  total_jobs integer DEFAULT 0,
  total_reviews integer DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE contractor_profiles ENABLE ROW LEVEL SECURITY;

-- Contractors can manage their own profiles
CREATE POLICY "Contractors can manage own profile"
  ON contractor_profiles
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM users 
      WHERE users.id = auth.uid() 
      AND users.id = contractor_profiles.user_id
      AND users.user_type = 'contractor'
    )
  );

-- Public can read contractor profiles
CREATE POLICY "Public can read contractor profiles"
  ON contractor_profiles
  FOR SELECT
  TO authenticated
  USING (true);

-- Trigger to automatically update updated_at
CREATE TRIGGER update_contractor_profiles_updated_at
  BEFORE UPDATE ON contractor_profiles
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- Function to automatically create contractor profile when contractor user is created
CREATE OR REPLACE FUNCTION create_contractor_profile()
RETURNS TRIGGER AS $$
BEGIN
  IF NEW.user_type = 'contractor' THEN
    INSERT INTO contractor_profiles (user_id)
    VALUES (NEW.id);
  END IF;
  RETURN NEW;
END;
$$ language 'plpgsql';

-- Trigger to create contractor profile
CREATE TRIGGER create_contractor_profile_trigger
  AFTER INSERT ON users
  FOR EACH ROW
  EXECUTE FUNCTION create_contractor_profile();