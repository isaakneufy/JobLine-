/*
  # Create jobs table

  1. New Tables
    - `jobs`
      - `id` (uuid, primary key)
      - `consumer_id` (uuid, foreign key) - references users table
      - `title` (text) - job title/summary
      - `description` (text) - detailed job description
      - `category` (text) - job category (plumbing, electrical, etc.)
      - `budget_min` (decimal) - minimum budget
      - `budget_max` (decimal) - maximum budget
      - `timeline` (text) - expected timeline
      - `location` (text) - job location
      - `address` (text, optional) - specific address
      - `images` (text array) - job images URLs
      - `requirements` (text array) - specific requirements
      - `status` (text) - job status
      - `urgency` (text) - urgency level
      - `preferred_contact` (text) - preferred contact method
      - `created_at` (timestamp)
      - `updated_at` (timestamp)

  2. Security
    - Enable RLS on `jobs` table
    - Add policy for consumers to manage their own jobs
    - Add policy for contractors to view open jobs
    - Add policy for job participants to view job details
*/

CREATE TABLE IF NOT EXISTS jobs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  consumer_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  title text NOT NULL,
  description text NOT NULL,
  category text NOT NULL,
  budget_min decimal(10,2),
  budget_max decimal(10,2),
  timeline text NOT NULL,
  location text NOT NULL,
  address text,
  images text[] DEFAULT '{}',
  requirements text[] DEFAULT '{}',
  status text NOT NULL DEFAULT 'open' CHECK (status IN ('open', 'in_progress', 'completed', 'cancelled')),
  urgency text DEFAULT 'normal' CHECK (urgency IN ('low', 'normal', 'high', 'urgent')),
  preferred_contact text DEFAULT 'app' CHECK (preferred_contact IN ('app', 'phone', 'email')),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE jobs ENABLE ROW LEVEL SECURITY;

-- Consumers can manage their own jobs
CREATE POLICY "Consumers can manage own jobs"
  ON jobs
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM users 
      WHERE users.id = auth.uid() 
      AND users.id = jobs.consumer_id
      AND users.user_type = 'consumer'
    )
  );

-- Contractors can view open jobs
CREATE POLICY "Contractors can view open jobs"
  ON jobs
  FOR SELECT
  TO authenticated
  USING (
    status = 'open' AND
    EXISTS (
      SELECT 1 FROM users 
      WHERE users.id = auth.uid() 
      AND users.user_type = 'contractor'
    )
  );

-- Job participants can view job details (consumer + assigned contractor)
CREATE POLICY "Job participants can view details"
  ON jobs
  FOR SELECT
  TO authenticated
  USING (
    auth.uid() = consumer_id OR
    EXISTS (
      SELECT 1 FROM job_applications 
      WHERE job_applications.job_id = jobs.id 
      AND job_applications.contractor_id = auth.uid()
      AND job_applications.status = 'accepted'
    )
  );

-- Trigger to automatically update updated_at
CREATE TRIGGER update_jobs_updated_at
  BEFORE UPDATE ON jobs
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();