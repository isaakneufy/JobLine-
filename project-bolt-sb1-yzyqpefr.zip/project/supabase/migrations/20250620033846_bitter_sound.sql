/*
  # Create job categories and performance indexes

  1. New Tables
    - `job_categories`
      - `id` (uuid, primary key)
      - `name` (text) - category name
      - `description` (text) - category description
      - `icon` (text) - icon name or URL
      - `parent_id` (uuid, optional) - for subcategories
      - `active` (boolean) - whether category is active
      - `sort_order` (integer) - display order

  2. Indexes
    - Performance indexes for common queries

  3. Sample Data
    - Insert common job categories
*/

CREATE TABLE IF NOT EXISTS job_categories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text UNIQUE NOT NULL,
  description text,
  icon text,
  parent_id uuid REFERENCES job_categories(id) ON DELETE CASCADE,
  active boolean DEFAULT true,
  sort_order integer DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE job_categories ENABLE ROW LEVEL SECURITY;

-- Public can read active categories
CREATE POLICY "Public can read active categories"
  ON job_categories
  FOR SELECT
  TO authenticated
  USING (active = true);

-- Insert common job categories
INSERT INTO job_categories (name, description, icon, sort_order) VALUES
  ('Plumbing', 'Pipe repairs, installations, and maintenance', 'wrench', 1),
  ('Electrical', 'Wiring, outlets, lighting, and electrical repairs', 'zap', 2),
  ('Carpentry', 'Wood work, furniture repair, custom builds', 'hammer', 3),
  ('Painting', 'Interior and exterior painting services', 'paintbrush', 4),
  ('Landscaping', 'Lawn care, gardening, outdoor maintenance', 'tree-pine', 5),
  ('Cleaning', 'House cleaning, deep cleaning, maintenance', 'spray-can', 6),
  ('Handyman', 'General repairs and maintenance tasks', 'tools', 7),
  ('Moving', 'Moving services and heavy lifting', 'truck', 8),
  ('HVAC', 'Heating, ventilation, and air conditioning', 'thermometer', 9),
  ('Roofing', 'Roof repairs, installations, and maintenance', 'home', 10),
  ('Flooring', 'Floor installation, repair, and refinishing', 'square', 11),
  ('Appliance Repair', 'Repair and maintenance of home appliances', 'settings', 12)
ON CONFLICT (name) DO NOTHING;

-- Performance indexes
CREATE INDEX IF NOT EXISTS idx_jobs_status ON jobs(status);
CREATE INDEX IF NOT EXISTS idx_jobs_category ON jobs(category);
CREATE INDEX IF NOT EXISTS idx_jobs_consumer_id ON jobs(consumer_id);
CREATE INDEX IF NOT EXISTS idx_jobs_created_at ON jobs(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_jobs_location ON jobs(location);
CREATE INDEX IF NOT EXISTS idx_jobs_budget ON jobs(budget_min, budget_max);

CREATE INDEX IF NOT EXISTS idx_job_applications_job_id ON job_applications(job_id);
CREATE INDEX IF NOT EXISTS idx_job_applications_contractor_id ON job_applications(contractor_id);
CREATE INDEX IF NOT EXISTS idx_job_applications_status ON job_applications(status);

CREATE INDEX IF NOT EXISTS idx_contractor_profiles_user_id ON contractor_profiles(user_id);
CREATE INDEX IF NOT EXISTS idx_contractor_profiles_rating ON contractor_profiles(average_rating DESC);
CREATE INDEX IF NOT EXISTS idx_contractor_profiles_specialties ON contractor_profiles USING GIN(specialties);

CREATE INDEX IF NOT EXISTS idx_reviews_reviewee_id ON reviews(reviewee_id);
CREATE INDEX IF NOT EXISTS idx_reviews_job_id ON reviews(job_id);
CREATE INDEX IF NOT EXISTS idx_reviews_rating ON reviews(rating);

CREATE INDEX IF NOT EXISTS idx_users_user_type ON users(user_type);
CREATE INDEX IF NOT EXISTS idx_users_location ON users(location);