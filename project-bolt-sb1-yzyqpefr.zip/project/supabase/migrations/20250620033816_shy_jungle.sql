/*
  # Create reviews table

  1. New Tables
    - `reviews`
      - `id` (uuid, primary key)
      - `job_id` (uuid, foreign key) - references jobs table
      - `reviewer_id` (uuid, foreign key) - who wrote the review
      - `reviewee_id` (uuid, foreign key) - who is being reviewed
      - `rating` (integer) - rating from 1-5
      - `comment` (text) - review comment
      - `review_type` (text) - 'consumer_to_contractor' or 'contractor_to_consumer'
      - `created_at` (timestamp)
      - `updated_at` (timestamp)

  2. Security
    - Enable RLS on `reviews` table
    - Add policy for job participants to create reviews
    - Add policy for public read access to contractor reviews
    - Add policy for users to read reviews about them

  3. Functions
    - Function to update contractor average rating when review is added/updated
*/

CREATE TABLE IF NOT EXISTS reviews (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  job_id uuid NOT NULL REFERENCES jobs(id) ON DELETE CASCADE,
  reviewer_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  reviewee_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  rating integer NOT NULL CHECK (rating >= 1 AND rating <= 5),
  comment text NOT NULL,
  review_type text NOT NULL CHECK (review_type IN ('consumer_to_contractor', 'contractor_to_consumer')),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(job_id, reviewer_id, reviewee_id)
);

-- Enable RLS
ALTER TABLE reviews ENABLE ROW LEVEL SECURITY;

-- Job participants can create reviews
CREATE POLICY "Job participants can create reviews"
  ON reviews
  FOR INSERT
  TO authenticated
  WITH CHECK (
    reviewer_id = auth.uid() AND
    (
      -- Consumer reviewing contractor
      (review_type = 'consumer_to_contractor' AND
       EXISTS (
         SELECT 1 FROM jobs j
         JOIN job_applications ja ON j.id = ja.job_id
         WHERE j.id = job_id 
         AND j.consumer_id = auth.uid()
         AND ja.contractor_id = reviewee_id
         AND ja.status = 'accepted'
         AND j.status = 'completed'
       )) OR
      -- Contractor reviewing consumer
      (review_type = 'contractor_to_consumer' AND
       EXISTS (
         SELECT 1 FROM jobs j
         JOIN job_applications ja ON j.id = ja.job_id
         WHERE j.id = job_id 
         AND ja.contractor_id = auth.uid()
         AND j.consumer_id = reviewee_id
         AND ja.status = 'accepted'
         AND j.status = 'completed'
       ))
    )
  );

-- Users can read reviews about them
CREATE POLICY "Users can read reviews about them"
  ON reviews
  FOR SELECT
  TO authenticated
  USING (reviewee_id = auth.uid() OR reviewer_id = auth.uid());

-- Public can read contractor reviews
CREATE POLICY "Public can read contractor reviews"
  ON reviews
  FOR SELECT
  TO authenticated
  USING (
    review_type = 'consumer_to_contractor' AND
    EXISTS (
      SELECT 1 FROM users 
      WHERE users.id = reviewee_id 
      AND users.user_type = 'contractor'
    )
  );

-- Trigger to automatically update updated_at
CREATE TRIGGER update_reviews_updated_at
  BEFORE UPDATE ON reviews
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- Function to update contractor ratings and stats
CREATE OR REPLACE FUNCTION update_contractor_stats()
RETURNS TRIGGER AS $$
BEGIN
  -- Update contractor profile stats
  UPDATE contractor_profiles 
  SET 
    average_rating = (
      SELECT COALESCE(AVG(rating), 0)
      FROM reviews 
      WHERE reviewee_id = COALESCE(NEW.reviewee_id, OLD.reviewee_id)
      AND review_type = 'consumer_to_contractor'
    ),
    total_reviews = (
      SELECT COUNT(*)
      FROM reviews 
      WHERE reviewee_id = COALESCE(NEW.reviewee_id, OLD.reviewee_id)
      AND review_type = 'consumer_to_contractor'
    ),
    total_jobs = (
      SELECT COUNT(DISTINCT job_id)
      FROM reviews 
      WHERE reviewee_id = COALESCE(NEW.reviewee_id, OLD.reviewee_id)
      AND review_type = 'consumer_to_contractor'
    ),
    updated_at = now()
  WHERE user_id = COALESCE(NEW.reviewee_id, OLD.reviewee_id);
  
  RETURN COALESCE(NEW, OLD);
END;
$$ language 'plpgsql';

-- Trigger to update contractor stats when review is added/updated/deleted
CREATE TRIGGER update_contractor_stats_trigger
  AFTER INSERT OR UPDATE OR DELETE ON reviews
  FOR EACH ROW
  EXECUTE FUNCTION update_contractor_stats();