/*
  # Create job applications table

  1. New Tables
    - `job_applications`
      - `id` (uuid, primary key)
      - `job_id` (uuid, foreign key) - references jobs table
      - `contractor_id` (uuid, foreign key) - references users table
      - `message` (text) - application message from contractor
      - `proposed_price` (decimal) - contractor's proposed price
      - `estimated_duration` (text) - estimated time to complete
      - `availability` (text) - when contractor can start
      - `status` (text) - application status
      - `consumer_notes` (text, optional) - notes from consumer
      - `created_at` (timestamp)
      - `updated_at` (timestamp)

  2. Security
    - Enable RLS on `job_applications` table
    - Add policy for contractors to manage their own applications
    - Add policy for consumers to view applications for their jobs
    - Add policy for consumers to update application status
*/

CREATE TABLE IF NOT EXISTS job_applications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  job_id uuid NOT NULL REFERENCES jobs(id) ON DELETE CASCADE,
  contractor_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  message text NOT NULL,
  proposed_price decimal(10,2) NOT NULL,
  estimated_duration text NOT NULL,
  availability text NOT NULL,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'accepted', 'rejected', 'withdrawn')),
  consumer_notes text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(job_id, contractor_id)
);

-- Enable RLS
ALTER TABLE job_applications ENABLE ROW LEVEL SECURITY;

-- Contractors can manage their own applications
CREATE POLICY "Contractors can manage own applications"
  ON job_applications
  FOR ALL
  TO authenticated
  USING (
    contractor_id = auth.uid() AND
    EXISTS (
      SELECT 1 FROM users 
      WHERE users.id = auth.uid() 
      AND users.user_type = 'contractor'
    )
  );

-- Consumers can view applications for their jobs
CREATE POLICY "Consumers can view applications for their jobs"
  ON job_applications
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM jobs 
      WHERE jobs.id = job_applications.job_id 
      AND jobs.consumer_id = auth.uid()
    )
  );

-- Consumers can update application status for their jobs
CREATE POLICY "Consumers can update application status"
  ON job_applications
  FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM jobs 
      WHERE jobs.id = job_applications.job_id 
      AND jobs.consumer_id = auth.uid()
    )
  );

-- Trigger to automatically update updated_at
CREATE TRIGGER update_job_applications_updated_at
  BEFORE UPDATE ON job_applications
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- Function to update job status when application is accepted
CREATE OR REPLACE FUNCTION update_job_status_on_acceptance()
RETURNS TRIGGER AS $$
BEGIN
  IF NEW.status = 'accepted' AND OLD.status != 'accepted' THEN
    -- Update job status to in_progress
    UPDATE jobs 
    SET status = 'in_progress', updated_at = now()
    WHERE id = NEW.job_id;
    
    -- Reject all other applications for this job
    UPDATE job_applications 
    SET status = 'rejected', updated_at = now()
    WHERE job_id = NEW.job_id AND id != NEW.id AND status = 'pending';
  END IF;
  RETURN NEW;
END;
$$ language 'plpgsql';

-- Trigger to update job status when application is accepted
CREATE TRIGGER update_job_status_on_acceptance_trigger
  AFTER UPDATE ON job_applications
  FOR EACH ROW
  EXECUTE FUNCTION update_job_status_on_acceptance();